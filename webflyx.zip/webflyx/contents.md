# contents

- titles.md: The movie titles in the WebFlyx collection
- classics.csv: A comma-separated list of classic movies
- quotes: A directory of files containing memorable quotes from movies
